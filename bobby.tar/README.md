# Movie-Hunter
Movie Hunter is a website which can help the user to choose the movie of his or her liking showing in theatres nearby
